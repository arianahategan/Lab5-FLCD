package table;

public class ParseTable {
}
