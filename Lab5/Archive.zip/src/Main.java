import grammar.Grammar;

public class Main {

    public static void main(String[] args) {
        Grammar grammar = new Grammar("grammar.in");
        System.out.println(grammar);
    }
}
